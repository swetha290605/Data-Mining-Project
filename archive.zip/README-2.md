# 🏥 Synthetic EHR Dataset (10% Demo, 7 Languages)

This dataset is a **demo version (10%)** of a larger multilingual synthetic longitudinal EHR (Electronic Health Records) dataset. It contains **simulated clinical records** for 100,000 fictitious patients, translated into **7 languages**: English, Spanish, French, Portuguese, Hindi, Russian, and Arabic.

---

## 📊 What’s Included?

This dataset includes:

- 🔢 `ehr_10pct_[LANG].csv`: One file per language, each with 10,000 fictional longitudinal patient records.
- 📚 `diccionario_variables.csv`: Explanation of each variable used in the dataset (per language).
- 📄 `LICENSE.txt`: Usage rights and limitations.
- 📘 `README.md`: This documentation.
- 📝 `product_description.txt` or `.docx`: Marketplace-ready content.

> All data is synthetic, does **not represent real patients**, and complies with privacy and data protection standards (GDPR, HIPAA-like).

---

## 💡 Use Cases

- Training and benchmarking ML models
- Dashboard and visualization prototyping
- EHR structure testing
- NLP multilingual pipelines
- Clinical predictive modeling

---

## 🌍 Supported Languages

- 🇺🇸 English  
- 🇪🇸 Spanish  
- 🇫🇷 French  
- 🇵🇹 Portuguese  
- 🇮🇳 Hindi  
- 🇷🇺 Russian  
- 🇸🇦 Arabic  

---

## 📎 Citation & DOI

If you use this dataset in your project or publication, please cite it:

[![DOI](https://zenodo.org/badge/DOI/10.34740/kaggle/dsv/12247241.svg)](https://doi.org/10.34740/kaggle/dsv/12247241)

```bibtex
@misc{enrique_mas_2025,
  title={Synthetic EHR Dataset (10 % demo, 7 languages)},
  url={https://www.kaggle.com/datasets/enriquemas/synthetic-ehr-dataset-10-demo-7-languages},
  DOI={10.34740/KAGGLE/DSV/12247241},
  publisher={Kaggle},
  author={Enrique Mas},
  year={2025}
}
```

---

## 📫 Contact

Questions or collaborations?  
📩 **em@sianabox.com**

---

## ⚠️ Legal & Licensing

- All data is simulated and for **research, educational, and commercial** uses.
- Cannot be used for real clinical decision-making or presented as real patient data.
- See `LICENSE.txt` for full terms.